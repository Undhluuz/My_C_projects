﻿using System;
using System.ComponentModel;
using System.Windows.Input;
using SimpleAccounting.DataAccess.Models;

namespace SimpleAccounting.ViewModels
{
    public class AddCounterpartyViewModel : INotifyPropertyChanged
    {
        private string _name;
        private string _taxId;
        private Counterparty _newCounterparty;

        public Counterparty NewCounterparty
        {
            get { return _newCounterparty; }
            set
            {
                _newCounterparty = value;
                OnPropertyChanged(nameof(NewCounterparty));
            }
        }

        public string Name
        {
            get { return _name; }
            set
            {
                _name = value;
                OnPropertyChanged(nameof(Name));
            }
        }

        public string TaxId
        {
            get { return _taxId; }
            set
            {
                _taxId = value;
                OnPropertyChanged(nameof(TaxId));
            }
        }
        public ICommand AddCounterpartyCommand { get; private set; }
        public ICommand CancelCommand { get; private set; }

        public AddCounterpartyViewModel()
        {
            AddCounterpartyCommand = new RelayCommand(AddCounterparty);
            CancelCommand = new RelayCommand(Cancel);
        }

        private void AddCounterparty(object parameter)
        {
            NewCounterparty = new Counterparty
            {
                Name = Name,
                TaxId = TaxId
            };
        }
        private void Cancel(object parameter)
        {
            // implementation for cancelling
        }
        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}