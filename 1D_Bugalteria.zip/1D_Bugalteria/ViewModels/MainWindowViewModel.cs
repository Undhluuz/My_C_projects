﻿using SimpleAccounting.DataAccess;
using SimpleAccounting.DataAccess.Models;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Input; // Добавляем для ICommand
using System.Runtime.CompilerServices;
using System.Data.Entity; // Добавляем для CallerMemberName

namespace SimpleAccounting.ViewModels
{
    public class MainWindowViewModel : INotifyPropertyChanged
    {
        // Приватные поля (private fields)
        private ObservableCollection<Counterparty> _counterparties;
        private Counterparty _selectedCounterparty; // Для выбранного контрагента
        private string _newCounterpartyName; // Для добавления нового контрагента
        private string _newCounterpartyTaxId; // Для добавления нового контрагента

        // Публичные свойства (public properties)
        public ObservableCollection<Counterparty> Counterparties
        {
            get { return _counterparties; }
            set
            {
                _counterparties = value;
                OnPropertyChanged(nameof(Counterparties));
            }
        }

        public Counterparty SelectedCounterparty
        {
            get { return _selectedCounterparty; }
            set
            {
                _selectedCounterparty = value;
                OnPropertyChanged(nameof(SelectedCounterparty));
            }
        }

        public string NewCounterpartyName
        {
            get { return _newCounterpartyName; }
            set
            {
                _newCounterpartyName = value;
                OnPropertyChanged(nameof(NewCounterpartyName));
            }
        }

        public string NewCounterpartyTaxId
        {
            get { return _newCounterpartyTaxId; }
            set
            {
                _newCounterpartyTaxId = value;
                OnPropertyChanged(nameof(NewCounterpartyTaxId));
            }
        }

        // Команды (Commands)
        public ICommand AddCounterpartyCommand { get; private set; }
        public ICommand DeleteCounterpartyCommand { get; private set; }
        public ICommand ShowDetailsCommand { get; private set; }

        // Конструктор (Constructor)
        public MainWindowViewModel()
        {
            // Инициализация команд (Initialize commands)
            AddCounterpartyCommand = new RelayCommand(AddCounterparty, CanAddCounterparty);
            DeleteCounterpartyCommand = new RelayCommand(DeleteCounterparty, CanDeleteCounterparty);
            ShowDetailsCommand = new RelayCommand(ShowDetails, CanShowDetails);

            // Загрузка данных (Load data)
            try
            {
                using (var db = new AppDbContext())
                {
                    db.Counterparties.Load();
                    Counterparties = new ObservableCollection<Counterparty>(db.Counterparties.Local);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}");
            }
        }

        // Методы для команд (Methods for commands)
        private bool CanAddCounterparty(object parameter)
        {
            // Проверяем, что имя и ИНН не пустые (Check that name and tax ID are not empty)
            return !string.IsNullOrEmpty(NewCounterpartyName) && !string.IsNullOrEmpty(NewCounterpartyTaxId);
        }

        private void AddCounterparty(object parameter)
        {
            var addCounterpartyWindow = new AddCounterpartyWindow(new AddCounterpartyViewModel());
            if (addCounterpartyWindow.ShowDialog() == true)
            {
                var newCounterpartyViewModel = (AddCounterpartyViewModel)addCounterpartyWindow.DataContext;
                if (newCounterpartyViewModel != null && newCounterpartyViewModel.NewCounterparty != null)
                {
                    using (var db = new AppDbContext())
                    {
                        db.Counterparties.Add(newCounterpartyViewModel.NewCounterparty);
                        db.SaveChanges();

                        // Обновляем коллекцию
                        Counterparties.Add(newCounterpartyViewModel.NewCounterparty);
                    }
                }
            }
        }

        private bool CanDeleteCounterparty(object parameter)
        {
            // Проверяем, что выбран контрагент (Check that a counterparty is selected)
            return SelectedCounterparty != null;
        }

        private void DeleteCounterparty(object parameter)
        {
            if (SelectedCounterparty != null)
            {
                using (var db = new AppDbContext())
                {
                    // Загружаем контрагента из базы данных
                    var counterpartyToDelete = db.Counterparties.Find(SelectedCounterparty.Id);

                    if (counterpartyToDelete != null)
                    {
                        db.Counterparties.Remove(counterpartyToDelete);
                        db.SaveChanges();

                        // Обновляем коллекцию
                        Counterparties.Remove(SelectedCounterparty);  // Удаляем из ObservableCollection
                        SelectedCounterparty = null;
                    }
                    else
                    {
                        MessageBox.Show("Контрагент не найден в базе данных.");
                    }
                }
            }
        }

        private bool CanShowDetails(object parameter)
        {
            // Проверяем, что выбран контрагент (Check that a counterparty is selected)
            return SelectedCounterparty != null;
        }

        private void ShowDetails(object parameter)
        {
            // Отображаем детали контрагента (Display counterparty details)
            if (SelectedCounterparty != null)
            {
                MessageBox.Show($"Name: {SelectedCounterparty.Name}\nTax ID: {SelectedCounterparty.TaxId}");
            }
        }

        // Реализация INotifyPropertyChanged (Implementation of INotifyPropertyChanged)
        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    // Простая реализация ICommand (Simple implementation of ICommand)
    public class RelayCommand : ICommand
    {
        private readonly Action<object> _execute;
        private readonly Predicate<object> _canExecute;

        public RelayCommand(Action<object> execute, Predicate<object> canExecute = null)
        {
            _execute = execute ?? throw new ArgumentNullException("execute");
            _canExecute = canExecute;
        }

        public bool CanExecute(object parameter)
        {
            return _canExecute == null || _canExecute(parameter);
        }

        public void Execute(object parameter)
        {
            _execute(parameter);
        }

        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }
    }
}